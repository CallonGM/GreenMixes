```markdown
# GreenMixes — Coming Soon page

This repo contains a responsive "coming soon" landing page for GreenMixes.

Files included
- index.html — landing page
- styles.css — site styles
- script.js — client-side form logic + LinkedIn contact flow
- assets/logo.png — (place your uploaded logo here)
- assets/og-image.svg — social preview that references the logo
- .github/workflows/deploy.yml — optional Pages deploy workflow

Deployment (quick)
1. Save your uploaded logo as assets/logo.png.
2. Initialize the repo and push (commands below).
3. Merge the coming-soon PR (if you create one) and enable GitHub Pages in Settings → Pages (branch: main, folder: root).

Notes
- Form flow prepares a LinkedIn-ready message for the founders. For server-side lead capture later, I recommend Formspree or Netlify Forms.
- I included a simple OG SVG that references assets/logo.png. If you prefer a PNG OG image, I can generate one and add it.
```