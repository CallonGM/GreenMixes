// Lightweight form handling: validate and show founders' LinkedIn contact options.
// No company email yet — the form prepares a message for LinkedIn and gives quick links.

document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('leadForm');
  const statusEl = document.getElementById('formStatus');
  const mailtoBtn = document.getElementById('mailtoBtn');
  const yearEl = document.getElementById('year');

  const founders = [
    { name: 'Callon Peate', url: 'https://www.linkedin.com/in/callonpeate/' },
    { name: 'Dushanth Seevaratnam', url: 'https://www.linkedin.com/in/dushanth-seevaratnam/' }
  ];

  if (yearEl) yearEl.textContent = new Date().getFullYear();

  function showStatus(htmlContent, ok = true) {
    if (!statusEl) return;
    statusEl.hidden = false;
    statusEl.innerHTML = htmlContent;
    statusEl.style.borderColor = ok ? '#d4f0e6' : '#f5d0d0';
    statusEl.style.background = ok ? '#f1fff9' : '#fff5f5';
    statusEl.style.color = ok ? '#145144' : '#7a1b1b';
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      const data = {
        company: form.company.value.trim(),
        name: form.name.value.trim(),
        email: form.email.value.trim(),
        role: form.role.value.trim(),
        capacity: form.capacity.value,
        interest: form.interest.value,
        message: form.message.value.trim()
      };

      // Minimal validation
      if (!data.company || !data.name || !data.email || !data.capacity || !data.interest) {
        showStatus('Please complete required fields (company, name, email, capacity, interest).', false);
        return;
      }
      if (!data.email.includes('@')) {
        showStatus('Please provide a valid email address.', false);
        return;
      }

      const prepared = `Hello Callon/Dushanth,\n\nI am ${data.name} from ${data.company} (role: ${data.role || 'N/A'}).\n\nI'm interested in: ${data.interest}.\n\nApprox. annual output: ${data.capacity}.\n\nNotes: ${data.message || ''}`;

      const links = founders.map(f => `<a href="${f.url}" target="_blank" rel="noopener noreferrer">${f.name} on LinkedIn</a>`).join(' • ');

      const html = `
        <strong>Thanks — your request is ready.</strong>
        <p>You can contact the founders directly on LinkedIn to share your details and request a pilot/sample:</p>
        <p>${links}</p>
        <p>Below is a prepared message you can paste into LinkedIn messages. Use the button to copy it to your clipboard:</p>
        <pre id="copyText" style="white-space:pre-wrap;background:#fff;padding:.5rem;border-radius:6px;border:1px solid #e6f3ee;">${prepared}</pre>
        <p><button id="copyBtn" class="btn primary">Copy message</button></p>
        <p class="muted">We do not store or forward your form data. Use LinkedIn to contact the founders or return later.</p>
      `;

      showStatus(html, true);

      // Copy handler
      const copyBtn = document.getElementById('copyBtn');
      const copyText = document.getElementById('copyText');
      if (copyBtn && copyText) {
        copyBtn.addEventListener('click', function () {
          const text = copyText.textContent || '';
          navigator.clipboard.writeText(text).then(function () {
            showStatus('<strong>Copied to clipboard.</strong> Paste into LinkedIn message to contact the founders.');
          }, function () {
            showStatus('Unable to copy automatically. Please select and copy the text manually.');
          });
        });
      }
    });
  }

  if (mailtoBtn) {
    mailtoBtn.addEventListener('click', function () {
      window.open(founders[0].url, '_blank', 'noopener');
    });
  }
});